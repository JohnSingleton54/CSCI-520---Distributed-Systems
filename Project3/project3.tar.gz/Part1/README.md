# Blockchain Project

Grant Nelson and John M. Singleton

CSCI 520 - Distributed Systems

Due May 7, 2020 by 11:59 PM

## About this project

This is project 3, a Blockchain programming project.
This is written to work in python 3 and run using local ports or AWS nodes.

### Running unit-tests

$ `python -m unittest -v`

### Running the server

Each node is started with a given node ID.
Here is how to start node ID 0.

$ `python ./main.py 0`
